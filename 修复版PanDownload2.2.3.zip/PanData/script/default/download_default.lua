local curl = require "lcurl.safe"

script_info = {
	["title"] = "默认",
	["version"] = "0.7.6",
	["description"] = "更新时间：2020-07-02"
}

function onInitTask(task, user, file)
    if task:getType() == TASK_TYPE_BAIDU then
		if user == nil then
        task:setError(-1, "用户未登录")
		return true
	end

	local url = "http://127.0.0.1:9347/pcsdownload"
    local data = ""

	local c = curl.easy{
		url = url,
		post = 1,
        postfields = pd.urlEncode(file.path).."|"..user:getBDUSS().."|"..user:getCookie(),
        httpheader = {"Expect:"},
		followlocation = 1,
		ssl_verifyhost = 0,
        ssl_verifypeer = 0,
		timeout = 60,
		proxy = pd.getProxy(),
		writefunction = function(buffer)
			data = data .. buffer
			return #buffer
		end,
	}

    local _, e = c:perform()
    c:close()
    if e then
        return false
    end

	task:setUris(data)
    task:setOptions("user-agent", "netdisk;2.2.51.6;netdisk;10.0.63;PC;android-android;QTP/1.0.32.2")
        if file.size >= 8192 then
            task:setOptions("header", "Range:bytes=4096-8191")
        end
        task:setOptions("piece-length", "6m")
        task:setOptions("max-connection-per-server", "64")
        task:setOptions("allow-piece-length-change", "true")
        task:setOptions("enable-http-pipelining", "true")
        task:setIcon("icon/accelerate.png", "通道加速中")
    return true
   end
       if task:getType() == TASK_TYPE_SHARE_BAIDU then
	       local accelerate_url = "http://127.0.0.1:9347/download?method=1"
           local data = ""
           local postdata = string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid")
        if user ~= nil then
		    postdata = string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid").."|"..user:getBDUSS().."|"..user:getCookie()
		end

    local c = curl.easy {
        url = accelerate_url,
        post = 1,
        httpheader = {"Expect:"},
        postfields = postdata,
        timeout = 60,
        ssl_verifyhost = 0,
        ssl_verifypeer = 0,
        proxy = pd.getProxy(),
        writefunction = function(buffer)
            data = data .. buffer
            return #buffer
        end,
    }
    local _, e = c:perform()
    c:close()
    if e then
        return false
    end

        local d_start = string.find(data, "//") + 2
        local d_end = string.find(data, "%.") - 1
        local downloadURL = string.sub(data, d_start, d_end)
    if string.find(downloadURL, "qdall") ~= nil then
           local accelerate_url2 = "http://127.0.0.1:9347/download?ck=svip&method=2"
           local data2 = ""
           local postdata2 = string.gsub(string.gsub(file.dlink, "https://d.pcs.baidu.com/file/", "&path="), "?fid", "&fid")

    local d = curl.easy {
        url = accelerate_url2,
        post = 1,
        httpheader = {"Expect:"},
        postfields = postdata2,
        timeout = 60,
        ssl_verifyhost = 0,
        ssl_verifypeer = 0,
        proxy = pd.getProxy(),
        writefunction = function(buffer)
            data2 = data2 .. buffer
            return #buffer
        end,
    }
        local _, t = d:perform()
    d:close()
    if t then
        return false
    end
            task:setUris(data2)
    task:setOptions("user-agent", "netdisk;2.2.51.6;netdisk;10.0.63;PC;android-android;QTP/1.0.32.2")
        if file.size >= 8192 then
            task:setOptions("header", "Range:bytes=4096-8191")
        end
        task:setOptions("piece-length", "6m")
        task:setOptions("max-connection-per-server", "64")
        task:setOptions("allow-piece-length-change", "true")
        task:setOptions("enable-http-pipelining", "true")
        task:setIcon("icon/accelerate.png", "通道加速中")
    return true
        
    end
    
    task:setUris(data)
    task:setOptions("user-agent", "netdisk;2.2.51.6;netdisk;10.0.63;PC;android-android;QTP/1.0.32.2")
        if file.size >= 8192 then
            task:setOptions("header", "Range:bytes=4096-8191")
        end
        task:setOptions("piece-length", "6m")
        task:setOptions("max-connection-per-server", "64")
        task:setOptions("allow-piece-length-change", "true")
        task:setOptions("enable-http-pipelining", "true")
        task:setIcon("icon/accelerate.png", "通道加速中")
    return true
	   end
 end